import { useState } from 'react'
import './App.css'

const App = () => {

  let time = new Date().toLocaleDateString();

  const [ctime, setCtime] = useState(time);

  const UpdateTime = () => {
    time = new Date().toLocaleTimeString();
    setCtime(time);
  };

  setInterval(UpdateTime,1000)

  return (
    <>
    <div className="tempo">
     <h1 className='hora'>{ctime}</h1> 
     <button className="btn" onClick={UpdateTime}>
      Ver o tempo
     </button>
    </div>
     
    </>
  )
}

export default App
