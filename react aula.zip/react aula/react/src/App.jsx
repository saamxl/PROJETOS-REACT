import { useState } from 'react';
import './App.css';

function App() {
 const [value, setValue] = useState(0);

  return (
    <>
      <div>
        <h2>Contadora React</h2>
        <p>{value}</p>
        <button className='botoes' onClick={() => setValue(value + 1)}>Acrescentar</button>
        <button className='botoes' onClick={() => setValue(value - 1)}>Subtrair</button>
        <button className='botoes' onClick={() => setValue(0)}>Resetar</button>
      </div>
     
    </>
  );
}

export default App;
